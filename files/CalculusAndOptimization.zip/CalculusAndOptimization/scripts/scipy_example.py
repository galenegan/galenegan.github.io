import numpy as np
from scipy.optimize import minimize


# Define the objective function for a vector of 50 elements
def objective_function(x):
    # Sum involving each element of x
    return sum(
        0.1 * (x[i] - (i + 1)) ** 2
        + np.sin(x[i]) * np.cos(x[(i + 1) % 50])
        + np.exp(-x[i] ** 2)
        for i in range(50)
    )


# Initial guess for a vector of 50 elements
initial_guess = np.random.rand(50)

# Bounds
bounds = [(-np.inf, 1) for i in range(10)]
bounds += [(-np.inf, 20) for i in range(10, 50)]

# Call minimize
result = minimize(
    objective_function, x0=initial_guess, bounds=bounds
)

# Output the results
if result.success:
    print("Optimal parameters found:", result.x)
    print("Minimum value of the function:", result.fun)
else:
    print("Optimization failed:", result.message)
