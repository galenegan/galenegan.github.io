import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

params = {
    "axes.labelsize": 16,
    "font.size": 16,
    "legend.fontsize": 14,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "font.family": "serif",
    "axes.grid": False,
    "text.usetex": True
}
plt.rcParams.update(params)

import matplotlib.pyplot as plt
import numpy as np

# Defining our function over some domain
x1 = np.linspace(-10, 10, 100)
x2 = np.linspace(-10, 10, 100)
X1, X2 = np.meshgrid(x1, x2)  # Turns 1d vectors x and y into 2d grids X and Y
a = 2
b = -3
def fxy(x1, x2, a, b):
    # Defines quadratic f(x1,x2) centered at (a,b)
    f = ((x1 - a)/4)**2 + ((x2 - b)/3)**2
    return f

# Initial guess, convergence tolerance, and learning rate
x_guess = np.array([8, 8])
cost_reduction = np.inf
tolerance = 1e-6
learning_rate = 1e-2

# Momentum parameters
alpha = 0.8
z_previous = 0  # Initial z_previous

# Storing the convergence history
x_history = [x_guess]

while cost_reduction > tolerance:
    # Calculating cost with guess from previous iteration
    cost_pre = fxy(x_guess[0], x_guess[1], a, b)

    # Calculating gradient of the cost from the
    # partial derivatives evaluated at x_guess
    dfdx1 = 2 * (x_guess[0] - a) / 4
    dfdx2 = 2 * (x_guess[1] - b) / 3
    gradient = np.array([dfdx1, dfdx2])

    # Updating x_guess and calculating new cost
    z = alpha * z_previous + gradient
    x_guess = x_guess - learning_rate * z
    cost_post = fxy(x_guess[0], x_guess[1], a, b)
    x_history.append(x_guess)

    # Checking how much the cost has gone down
    cost_reduction = np.abs(cost_post - cost_pre)

    # Updating z
    z_previous = z.copy()

x_history = np.vstack(x_history)

# %% Plotting results
f = fxy(X1, X2, a, b)
fig, ax = plt.subplots()
levels = np.logspace(np.log(f.min()), np.log(f.max()), num=100, base=np.exp(1))
cs = ax.contourf(X1, X2, f, levels=levels, alpha=0.8)
# contour_lines = ax.contour(X1, X2, f, levels=levels, colors='w', linewidths=0.5)

# Plot gradient descent paths for each learning rate
ax.plot(x_history[:, 0], x_history[:, 1], '--', color="r", linewidth=2, label=f"LR={learning_rate}, Num Iter = {x_history.shape[0]}")

# Add colorbar and labels
cbar = fig.colorbar(cs, ax=ax, ticks=np.logspace(np.log(f.min()), np.log(f.max()), num=4, base=np.exp(1)))
ax.set_xlabel(r"$x_1$")
ax.set_ylabel(r"$x_2$")
ax.legend(loc="upper left")
fig.set_size_inches(6, 5)
fig.tight_layout(pad=0.5)
plt.savefig("gd_mom.png", dpi=300)
plt.show()