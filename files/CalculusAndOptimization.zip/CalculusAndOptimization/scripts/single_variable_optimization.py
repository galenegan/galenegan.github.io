import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

params = {
    "axes.labelsize": 20,
    "font.size": 20,
    "legend.fontsize": 16,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "font.family": "sans-serif",
    "axes.grid": False,
    "text.usetex": True
}
plt.rcParams.update(params)

x = np.linspace(-6, 2, 200)
fx = x**4 + 7 * x**3 + 5 * x**2 - 17 * x + 3
dfdx = 4 * x ** 3 + 21 * x ** 2 + 10 * x - 17

def min_func(x):
    return  x**4 + 7 * x**3 + 5 * x**2 - 17 * x + 3

res = minimize(min_func, x0=np.array([-4]))
#%%
fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
ax1.plot(x, fx, linewidth=2.5, alpha=0.8)
ax1.set_ylabel(f"Objective Function $f_0(x)$")
ax1.grid()

ax2.plot(x, dfdx, linewidth=2.5, alpha=0.8)
ax2.set_xlabel(r"Optimization Variable $x$")
ax2.set_ylabel(f"First Derivative $f_0^\prime(x)$")
ax2.grid()
fig.set_size_inches(7, 10)
fig.tight_layout(pad=0.5)


plt.savefig("1d_opt.png", dpi=300)
plt.show()