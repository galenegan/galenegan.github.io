import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

params = {
    "axes.labelsize": 16,
    "font.size": 16,
    "legend.fontsize": 14,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "font.family": "serif",
    "axes.grid": False,
    "text.usetex": True
}
plt.rcParams.update(params)

import matplotlib.pyplot as plt
import numpy as np

# %% Defining our function
x1 = np.linspace(-2, 10, 100)
x2 = np.linspace(-7, 10, 100)
X1, X2 = np.meshgrid(x1, x2)  # Turns 1d vectors x and y into 2d grids X and Y
x1_0 = 2
x2_0 = -3
f = ((X1 - x1_0) / 4) ** 2 + ((X2 - x2_0) / 3) ** 2  # Defines our values f(X1,X2)

# Define learning rates to compare
learning_rates = [0.01, 1, 1.75]
initial_guess = np.array([8, 9])
tolerance = 1e-6

# Store histories for each learning rate
all_histories = []
for learning_rate in learning_rates:
    x_guess = initial_guess.copy()
    x_history = [x_guess]
    cost_reduction = np.inf

    while cost_reduction > tolerance:
        cost_pre = ((x_guess[0] - x1_0) / 4) ** 2 + ((x_guess[1] - x2_0) / 3) ** 2
        dfdx1 = (x_guess[0] - x1_0) / 2
        dfdx2 = 2 * (x_guess[1] - x2_0) / 3
        gradient = np.array([dfdx1, dfdx2])
        x_guess = x_guess - learning_rate * gradient
        cost_post = ((x_guess[0] - x1_0) / 4) ** 2 + ((x_guess[1] - x2_0) / 3) ** 2
        x_history.append(x_guess)
        cost_reduction = np.abs(cost_post - cost_pre)

    all_histories.append(np.vstack(x_history))

# %% Plotting results
fig, ax = plt.subplots()
levels = np.logspace(np.log(f.min()), np.log(f.max()), num=100, base=np.exp(1))
cs = ax.contourf(X1, X2, f, levels=levels, alpha=0.8)
# contour_lines = ax.contour(X1, X2, f, levels=levels, colors='w', linewidths=0.5)

# Plot gradient descent paths for each learning rate
colors = ['r', 'g', 'b']
for i, (history, lr) in enumerate(zip(all_histories, learning_rates)):
    ax.plot(history[:, 0], history[:, 1], '--', color=colors[i], linewidth=2, label=f"LR={lr}, Num Iter = {history.shape[0]}")

# Add colorbar and labels
cbar = fig.colorbar(cs, ax=ax, ticks=np.logspace(np.log(f.min()), np.log(f.max()), num=4, base=np.exp(1)))
ax.set_xlabel(r"$x_1$")
ax.set_ylabel(r"$x_2$")
ax.legend(loc="upper left")
fig.set_size_inches(6, 5)
fig.tight_layout(pad=0.5)
plt.savefig("gd.png", dpi=300)
plt.show()



#%% For the notes


# # Defining our function over some domain
# x1 = np.linspace(-10, 10, 100)
# x2 = np.linspace(-10, 10, 100)
# X1, X2 = np.meshgrid(x1, x2)  # Turns 1d vectors x and y into 2d grids X and Y
# a = 2
# b = -3
# def fxy(x1, x2, a, b):
#     # Defines quadratic f(x1,x2) centered at (a,b)
#     f = ((x1 - a)/4)**2 + ((x2 - b)/3)**2
#     return f
#
# # Initial guess, convergence tolerance, and learning rate
# x_guess = np.array([8, 8])
# cost_reduction = np.inf
# tolerance = 1e-6
# learning_rate = 1e-2
# x_history = [x_guess]
#
# while cost_reduction > tolerance:
#     # Calculating cost with guess from previous iteration
#     cost_pre = fxy(x_guess[0], x_guess[1], a, b)
#
#     # Calculating gradient of the cost from the
#     # partial derivatives evaluated at x_guess
#     dfdx1 = (x_guess[0] - a) / 4
#     dfdx2 = 2 * (x_guess[1] - b) / 3
#     gradient = np.array([dfdx1, dfdx2])
#
#     # Updating x_guess and calculating new cost
#     x_guess = x_guess - learning_rate * gradient
#     cost_post = fxy(x_guess[0], x_guess[1], a, b)
#     x_history.append(x_guess)
#
#     # Checking how much the cost has gone down
#     cost_reduction = np.abs(cost_post - cost_pre)
#
# x_history = np.vstack(x_history)
#
# #%% Plotting results
# fig, ax = plt.subplots()
# levels = np.logspace(np.log(f.min()), np.log(f.max()), num=20, base=np.exp(1))
# cs = ax.contourf(X1, X2, f, levels=levels)
# contour_lines = ax.contour(X1, X2, f, levels=levels, colors='w', linewidths=0.5)
#
# # Plot the gradient descent path
# ax.plot(x_history[:, 0], x_history[:, 1], '-', color="r", linewidth=2, label="Gradient descent")
# cbar = fig.colorbar(cs, ax=ax, ticks=np.logspace(np.log(f.min()), np.log(f.max()), num=5, base=np.exp(1)))
# ax.set_xlabel(r"$x_1$")
# ax.set_ylabel(r"$x_2$")
# ax.legend()
# fig.set_size_inches(6, 5)
# fig.tight_layout(pad=0.5)
# plt.show()