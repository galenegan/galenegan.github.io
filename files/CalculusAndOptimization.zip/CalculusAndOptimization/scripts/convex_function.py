import matplotlib.pyplot as plt
import numpy as np

params = {
    "axes.labelsize": 16,
    "font.size": 16,
    "legend.fontsize": 14,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "font.family": "serif",
    "axes.grid": False,
    "text.usetex": True
}
plt.rcParams.update(params)

#%% Setup
x = np.linspace(-4, 3, 200)
fx = 2 * x**2 + 3 * x - 2

#%% Defining tangent line
xt = np.linspace(0.5, 2.5, 100)
x0 = 1.6
df_dx0 = 4 * x0 + 3
f_x0 = 2 * x0**2 + 3 * x0 - 2
ft = f_x0 + df_dx0 * (xt - x0)

#%% Defining chord
x1 = -2.3
x2 = -0.4
f_x1 = 2 * x1**2 + 3 * x1 - 2
f_x2 = 2 * x2**2 + 3 * x2 - 2
theta = np.linspace(1, 0, 100)
fc = theta * f_x1 + (1 - theta) * f_x2
xc = np.linspace(x1, x2, 100)


#%% Plotting everything
fig, ax = plt.subplots(figsize=(6, 5))
ax.plot(x, fx, alpha=0.75, linewidth=2, label=r"$f(x)$")
ax.plot(xt, ft, alpha=0.75, linewidth=2, label=r"$f(x_0) + \nabla f(x_0) (x - x_0)$")
ax.plot(xc, fc, alpha=0.75, linewidth=2, label=r"$\theta f(x_1) + (1 - \theta) f(x_2)$")
ax.plot([x0, x0], [-7.5, f_x0], '--', linewidth=2, color="0.25")
ax.plot([x1, x1], [-7.5, f_x1], '--', linewidth=2, color="0.25")
ax.plot([x2, x2], [-7.5, f_x2], '--', linewidth=2, color="0.25")
ax.legend()
ax.set_ylim(-7.5, 27.5)
ax.set_xlabel(r"$x$")
ax.set_ylabel(r"$f(x)$")
ax.annotate(r"$f^{\prime \prime}(x) \geq 0$", xy=(-1.25, 10))

# Handling x ticks
ticks = [x0, x1, x2]
ax.set_xticks(ticks)
ax.set_xticklabels([r"$x_0$", r"$x_1$", r"$x_2$"])
fig.tight_layout(pad=0.5)
plt.savefig("cvx_func.png", dpi=300)
plt.show()